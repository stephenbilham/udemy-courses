import React from "react";
import { connect } from "react-redux";
import { setTextFilter, sortByAmount, sortByDate } from "../actions/filters"; //function

const ExpenseListFilters = props => (
  <div>
    <input
      type="text"
      value={props.filters.text}
      onChange={e => {
        props.dispatch(setTextFilter(e.target.value));
      }}
      style={{ border: "1px solid grey" }}
    />
    <select
      value={props.filters.sortBy} //controlled input
      onChange={e => {
        if (e.target.value === "date") {
          console.log("hello");
          console.log(e.target.value);

          props.dispatch(sortByDate());
        } else if (e.target.value === "amount") {
          console.log("hello2");
          console.log(e.target.value);
          props.dispatch(sortByAmount());
        }
      }}
      style={{ margin: "8px", background: "white", border: "1px solid" }}
    >
      <option value="date">Date</option>
      <option value="amount">Amount</option>
    </select>
  </div>
);
const mapStateToProps = state => {
  return {
    filters: state.filters
  };
};

export default connect(mapStateToProps)(ExpenseListFilters);
