import React from "react";

const AddExpensePage = () => <div>this is my expense page</div>;

export default AddExpensePage;
