import React from "react";

const HelpPage = () => <div>this is my help page</div>;

export default HelpPage;
